# -*- coding: utf-8 -*-
"""Generate placeholder PNG assets for the Kivy ski game."""
import os
from PIL import Image, ImageDraw

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(BASE_DIR, "assets")
os.makedirs(ASSET_DIR, exist_ok=True)


def save(img, name):
    img.save(os.path.join(ASSET_DIR, name))


def skier():
    img = Image.new("RGBA", (54, 64), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.line((8, 56, 46, 62), fill=(35, 90, 170, 255), width=5)
    d.line((12, 48, 50, 54), fill=(35, 90, 170, 255), width=5)
    d.line((24, 38, 18, 52), fill=(35, 45, 65, 255), width=6)
    d.line((32, 39, 39, 50), fill=(35, 45, 65, 255), width=6)
    d.polygon([(18, 22), (37, 20), (41, 39), (22, 43)], fill=(220, 60, 70, 255))
    d.line((22, 26, 37, 25), fill=(250, 190, 60, 255), width=4)
    d.ellipse((19, 4, 37, 22), fill=(245, 205, 165, 255))
    d.polygon([(18, 10), (28, 1), (39, 9), (35, 12), (20, 13)], fill=(40, 55, 90, 255))
    d.rectangle((20, 12, 38, 17), fill=(20, 25, 35, 255))
    d.line((14, 28, 4, 55), fill=(80, 90, 105, 255), width=2)
    d.line((43, 27, 52, 54), fill=(80, 90, 105, 255), width=2)
    return img


def tree():
    img = Image.new("RGBA", (64, 78), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rectangle((27, 56, 37, 78), fill=(105, 72, 45, 255))
    d.polygon([(32, 2), (8, 34), (56, 34)], fill=(22, 105, 72, 255))
    d.polygon([(32, 18), (3, 55), (61, 55)], fill=(18, 88, 62, 255))
    d.polygon([(32, 2), (16, 28), (48, 28)], fill=(240, 250, 255, 255))
    d.polygon([(32, 18), (11, 48), (53, 48)], fill=(240, 250, 255, 255))
    return img


def rock():
    img = Image.new("RGBA", (58, 44), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.polygon([(5, 38), (14, 14), (30, 5), (50, 16), (53, 36), (39, 41), (17, 40)], fill=(105, 112, 122, 255))
    d.polygon([(14, 14), (30, 5), (43, 14), (29, 20)], fill=(150, 158, 168, 255))
    d.line((16, 34, 45, 31), fill=(70, 76, 86, 255), width=3)
    return img


def yeti():
    img = Image.new("RGBA", (76, 90), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((1, 26, 25, 72), fill=(226, 236, 245, 255))
    d.ellipse((51, 26, 75, 72), fill=(226, 236, 245, 255))
    d.ellipse((12, 18, 64, 78), fill=(245, 250, 255, 255))
    d.ellipse((17, 5, 59, 50), fill=(236, 244, 252, 255))
    d.ellipse((24, 16, 52, 46), fill=(145, 190, 220, 255))
    d.ellipse((26, 25, 34, 33), fill=(15, 25, 40, 255))
    d.ellipse((42, 25, 50, 33), fill=(15, 25, 40, 255))
    d.arc((29, 31, 47, 47), 0, 180, fill=(90, 40, 55, 255), width=3)
    for x in (8, 15, 22):
        d.line((x, 66, x - 4, 76), fill=(120, 135, 150, 255), width=2)
    for x in (68, 61, 54):
        d.line((x, 66, x + 4, 76), fill=(120, 135, 150, 255), width=2)
    return img


def shield():
    img = Image.new("RGBA", (38, 42), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.polygon([(19, 1), (36, 8), (34, 24), (19, 41), (4, 24), (2, 8)], fill=(56, 189, 248, 255), outline=(14, 80, 130, 255))
    d.polygon([(19, 7), (30, 12), (28, 23), (19, 34), (10, 23), (8, 12)], fill=(125, 211, 252, 255))
    d.line((19, 12, 19, 29), fill=(14, 80, 130, 255), width=3)
    return img


def penguin():
    img = Image.new("RGBA", (46, 52), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((7, 4, 39, 50), fill=(35, 40, 50, 255))
    d.ellipse((14, 18, 32, 46), fill=(245, 250, 255, 255))
    d.ellipse((13, 10, 21, 18), fill=(250, 250, 255, 255))
    d.ellipse((25, 10, 33, 18), fill=(250, 250, 255, 255))
    d.ellipse((16, 12, 19, 15), fill=(10, 15, 20, 255))
    d.ellipse((27, 12, 30, 15), fill=(10, 15, 20, 255))
    d.polygon([(21, 16), (25, 16), (23, 20)], fill=(250, 170, 40, 255))
    d.polygon([(13, 48), (23, 48), (18, 52)], fill=(250, 170, 40, 255))
    d.polygon([(23, 48), (33, 48), (28, 52)], fill=(250, 170, 40, 255))
    return img


def eagle():
    img = Image.new("RGBA", (64, 44), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.polygon([(4, 26), (30, 8), (60, 20), (42, 24), (58, 38), (34, 30), (10, 38)], fill=(120, 82, 45, 255))
    d.polygon([(28, 8), (38, 6), (34, 14)], fill=(235, 235, 240, 255))
    d.polygon([(38, 10), (47, 13), (39, 17)], fill=(245, 190, 50, 255))
    d.ellipse((31, 9, 34, 12), fill=(15, 15, 15, 255))
    return img


def snowmobile():
    img = Image.new("RGBA", (72, 42), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.polygon([(8, 24), (28, 12), (58, 14), (68, 26), (54, 31), (20, 31)], fill=(220, 50, 60, 255))
    d.rectangle((26, 6, 43, 16), fill=(70, 90, 120, 255))
    d.line((8, 34, 68, 34), fill=(30, 35, 45, 255), width=5)
    d.line((12, 38, 60, 38), fill=(80, 90, 110, 255), width=3)
    d.line((54, 14, 66, 5), fill=(40, 45, 60, 255), width=4)
    return img


def coin():
    img = Image.new("RGBA", (34, 34), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((2, 2, 32, 32), fill=(250, 204, 21, 255), outline=(180, 125, 20, 255), width=3)
    d.ellipse((9, 9, 25, 25), fill=(255, 235, 130, 255))
    d.polygon([(17, 8), (20, 15), (27, 15), (21, 19), (23, 26), (17, 22), (11, 26), (13, 19), (7, 15), (14, 15)], fill=(222, 160, 24, 255))
    return img


def boost():
    img = Image.new("RGBA", (38, 38), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rounded_rectangle((8, 3, 30, 35), radius=6, fill=(239, 68, 68, 255), outline=(120, 20, 25, 255), width=3)
    d.rectangle((14, 0, 24, 6), fill=(230, 230, 240, 255))
    d.polygon([(21, 8), (13, 21), (20, 21), (16, 32), (27, 17), (20, 17)], fill=(255, 255, 255, 255))
    return img


if __name__ == "__main__":
    save(skier(), "skier.png")
    save(tree(), "tree.png")
    save(rock(), "rock.png")
    save(yeti(), "yeti.png")
    save(coin(), "coin.png")
    save(boost(), "boost.png")
    save(shield(), "shield.png")
    save(penguin(), "penguin.png")
    save(eagle(), "eagle.png")
    save(snowmobile(), "snowmobile.png")
    print("assets generated")
