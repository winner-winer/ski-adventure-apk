# -*- coding: utf-8 -*-
"""Generate placeholder PNG assets for the Kivy ski game."""
import os
from PIL import Image, ImageDraw

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(BASE_DIR, "assets")
os.makedirs(ASSET_DIR, exist_ok=True)


def save(img, name):
    img.save(os.path.join(ASSET_DIR, name))


def skier():
    img = Image.new("RGBA", (54, 64), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.line((8, 56, 46, 62), fill=(35, 90, 170, 255), width=5)
    d.line((12, 48, 50, 54), fill=(35, 90, 170, 255), width=5)
    d.line((24, 38, 18, 52), fill=(35, 45, 65, 255), width=6)
    d.line((32, 39, 39, 50), fill=(35, 45, 65, 255), width=6)
    d.polygon([(18, 22), (37, 20), (41, 39), (22, 43)], fill=(220, 60, 70, 255))
    d.line((22, 26, 37, 25), fill=(250, 190, 60, 255), width=4)
    d.ellipse((19, 4, 37, 22), fill=(245, 205, 165, 255))
    d.polygon([(18, 10), (28, 1), (39, 9), (35, 12), (20, 13)], fill=(40, 55, 90, 255))
    d.rectangle((20, 12, 38, 17), fill=(20, 25, 35, 255))
    d.line((14, 28, 4, 55), fill=(80, 90, 105, 255), width=2)
    d.line((43, 27, 52, 54), fill=(80, 90, 105, 255), width=2)
    return img


def tree():
    img = Image.new("RGBA", (64, 78), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.rectangle((27, 56, 37, 78), fill=(105, 72, 45, 255))
    d.polygon([(32, 2), (8, 34), (56, 34)], fill=(22, 105, 72, 255))
    d.polygon([(32, 18), (3, 55), (61, 55)], fill=(18, 88, 62, 255))
    d.polygon([(32, 2), (16, 28), (48, 28)], fill=(240, 250, 255, 255))
    d.polygon([(32, 18), (11, 48), (53, 48)], fill=(240, 250, 255, 255))
    return img


def rock():
    img = Image.new("RGBA", (58, 44), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.polygon([(5, 38), (14, 14), (30, 5), (50, 16), (53, 36), (39, 41), (17, 40)], fill=(105, 112, 122, 255))
    d.polygon([(14, 14), (30, 5), (43, 14), (29, 20)], fill=(150, 158, 168, 255))
    d.line((16, 34, 45, 31), fill=(70, 76, 86, 255), width=3)
    return img


def yeti():
    img = Image.new("RGBA", (76, 90), (0, 0, 0, 0))
    d = ImageDraw.Draw(img)
    d.ellipse((1, 26, 25, 72), fill=(226, 236, 245, 255))
    d.ellipse((51, 26, 75, 72), fill=(226, 236, 245, 255))
    d.ellipse((12, 18, 64, 78), fill=(245, 250, 255, 255))
    d.ellipse((17, 5, 59, 50), fill=(236, 244, 252, 255))
    d.ellipse((24, 16, 52, 46), fill=(145, 190, 220, 255))
    d.ellipse((26, 25, 34, 33), fill=(15, 25, 40, 255))
    d.ellipse((42, 25, 50, 33), fill=(15, 25, 40, 255))
    d.arc((29, 31, 47, 47), 0, 180, fill=(90, 40, 55, 255), width=3)
    for x in (8, 15, 22):
        d.line((x, 66, x - 4, 76), fill=(120, 135, 150, 255), width=2)
    for x in (68, 61, 54):
        d.line((x, 66, x + 4, 76), fill=(120, 135, 150, 255), width=2)
    return img


if __name__ == "__main__":
    save(skier(), "skier.png")
    save(tree(), "tree.png")
    save(rock(), "rock.png")
    save(yeti(), "yeti.png")
    print("assets generated")
