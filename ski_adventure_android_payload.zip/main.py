# -*- coding: utf-8 -*-
"""Ski Safari style 2D game (Kivy/Android), easier landscape build.

Changes in this version:
- Landscape orientation.
- Sloped downhill terrain.
- Easier pacing: obstacles spawn farther apart.
- Pickups: coins (+50), energy drink (+150, short speed burst, pushes Yeti back).
- Jump/backflip/near-miss scoring kept, with gentler difficulty curve.
"""

import math
import os
import random

from kivy.app import App
from kivy.clock import Clock
from kivy.core.image import Image as CoreImage
from kivy.core.window import Window
from kivy.graphics import Color, Line, PopMatrix, PushMatrix, Rectangle, Rotate
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.widget import Widget

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(BASE_DIR, "assets")
PX_PER_METER = 18.0
YETI_START_DISTANCE = 2000.0

SKY = (170 / 255.0, 220 / 255.0, 245 / 255.0, 1)
SNOW = (245 / 255.0, 250 / 255.0, 255 / 255.0, 1)
SNOW_LINE = (198 / 255.0, 220 / 255.0, 236 / 255.0, 1)
HUD = (20 / 255.0, 30 / 255.0, 45 / 255.0, 1)
RED = (220 / 255.0, 45 / 255.0, 55 / 255.0, 1)
WHITE = (1, 1, 1, 1)
SHADE = (5 / 255.0, 10 / 255.0, 18 / 255.0, 0.62)


def clamp(value, lo, hi):
    return max(lo, min(hi, value))


def load_texture(name):
    return CoreImage(os.path.join(ASSET_DIR, name)).texture


class Obstacle(object):
    __slots__ = ("kind", "tex", "x", "y", "w", "h", "passed")

    def __init__(self, kind, tex, x, y):
        self.kind = kind
        self.tex = tex
        self.x = x
        self.y = y
        self.w = float(tex.width)
        self.h = float(tex.height)
        self.passed = False

    def half_size(self):
        if self.kind == "rock":
            return self.w * 0.42, self.h * 0.36
        return self.w * 0.28, self.h * 0.40


class Pickup(object):
    __slots__ = ("kind", "tex", "x", "y", "w", "h")

    def __init__(self, kind, tex, x, y):
        self.kind = kind
        self.tex = tex
        self.x = x
        self.y = y
        self.w = float(tex.width)
        self.h = float(tex.height)


def overlap(ax, ay, ahw, ahh, bx, by, bhw, bhh):
    return abs(ax - bx) < (ahw + bhw) and abs(ay - by) < (ahh + bhh)


class GameBoard(Widget):
    def __init__(self, **kwargs):
        super(GameBoard, self).__init__(**kwargs)
        self.textures = {
            "skier": load_texture("skier.png"),
            "tree": load_texture("tree.png"),
            "rock": load_texture("rock.png"),
            "yeti": load_texture("yeti.png"),
            "coin": load_texture("coin.png"),
            "boost": load_texture("boost.png"),
        }
        self.keys = set()
        self.touch = None
        self.bind(size=self._on_size)
        Window.bind(on_key_down=self._on_key_down)
        Window.bind(on_key_up=self._on_key_up)
        self.reset()
        Clock.schedule_interval(self.update, 1.0 / 60.0)

    def _on_size(self, *args):
        self.player_x = self.width * 0.28
        if self.on_ground:
            self.player_y = self.ground_y(self.player_x) + 34.0

    def reset(self):
        w = self.width or Window.width or 640
        h = self.height or Window.height or 360
        self.scroll = 0.0
        self.distance = 0.0
        self.score = 0
        self.speed_mps = 14.0
        self.boost = 0.0
        self.drink_timer = 0.0
        self.player_x = w * 0.28
        self.player_y = h * 0.58
        self.vy = 0.0
        self.on_ground = True
        self.rot = 0.0
        self.airtime = 0.0
        self.airborne_near_ob = False
        self.obstacles = []
        self.items = []
        self.spawn_timer = 1.0
        self.coin_timer = 0.5
        self.boost_timer = 5.0
        self.yeti_active = False
        self.yeti_x = -260.0
        self.yeti_speed = 0.0
        self.game_over = False
        self.paused = False
        self.hud_text = ""
        self.message_text = ""
        self.message_color = WHITE
        self.action_text = ""
        self.action_ttl = 0.0

    def _on_key_down(self, window, key, scancode, codepoint, modifiers):
        self.keys.add(key)
        if self.game_over and key == 114:  # R
            self.reset()
        elif key == 112 and not self.game_over:  # P
            self.paused = not self.paused
        elif key in (32, 273) and not self.game_over and not self.paused and self.on_ground:
            self.jump()
        return True

    def _on_key_up(self, window, key, scancode):
        self.keys.discard(key)
        return True

    def on_touch_down(self, touch):
        if self.game_over:
            self.reset()
            return True
        self.touch = touch
        if self.on_ground and not self.paused:
            self.jump()
        return True

    def on_touch_move(self, touch):
        self.touch = touch
        return True

    def on_touch_up(self, touch):
        if self.touch is touch:
            self.touch = None
        return True

    def ground_y(self, x):
        """Sloped downhill terrain: high on the left, lower toward the right."""
        h = self.height or Window.height or 360
        pos = self.scroll + x
        run = pos % 1900.0
        t = pos * 0.0045
        base = h * 0.52 - run * 0.030
        return base + 34.0 * math.sin(t) + 16.0 * math.sin(t * 0.53 + 1.1)

    def jump(self):
        self.on_ground = False
        self.vy = 590.0
        self.airtime = 0.0
        self.rot = 0.0
        self.airborne_near_ob = False
        self.add_score(10, "Jump +10")

    def add_score(self, points, label):
        self.score += int(points)
        self.action_text = label
        self.action_ttl = 1.2

    def rotate_input(self):
        if self.touch is not None:
            return True
        return (273 in self.keys) or (32 in self.keys)

    def spawn_obstacle(self):
        kind = "rock" if random.random() < 0.48 else "tree"
        tex = self.textures[kind]
        w = self.width or Window.width or 640
        rightmost = max([ob.x for ob in self.obstacles], default=0.0)
        x = max(w + random.uniform(170.0, 260.0), rightmost + random.uniform(430.0, 620.0))
        y = self.ground_y(x) + tex.height * 0.42
        self.obstacles.append(Obstacle(kind, tex, x, y))

    def spawn_coin_line(self):
        tex = self.textures["coin"]
        w = self.width or Window.width or 640
        start = w + random.uniform(60.0, 160.0)
        for i in range(5):
            x = start + i * 46.0
            y = self.ground_y(x) + 92.0 + 22.0 * math.sin(i * 0.9)
            self.items.append(Pickup("coin", tex, x, y))

    def spawn_boost(self):
        tex = self.textures["boost"]
        w = self.width or Window.width or 640
        x = w + random.uniform(160.0, 300.0)
        y = self.ground_y(x) + 112.0
        self.items.append(Pickup("boost", tex, x, y))

    def update(self, dt):
        dt = min(dt, 1.0 / 20.0)
        if self.game_over or self.paused:
            self._refresh_text()
            self.redraw()
            return

        if self.drink_timer > 0.0:
            self.drink_timer = max(0.0, self.drink_timer - dt)

        # Gentler acceleration curve than before.
        if self.on_ground:
            if self.touch is not None:
                if self.touch.y > self.height * 0.72:
                    self.boost += 20.0 * dt
                elif self.touch.y < self.height * 0.24:
                    self.boost -= 30.0 * dt
                else:
                    self.boost *= max(0.0, 1.0 - 1.8 * dt)
            else:
                if 273 in self.keys:
                    self.boost += 20.0 * dt
                elif 274 in self.keys:
                    self.boost -= 30.0 * dt
                else:
                    self.boost *= max(0.0, 1.0 - 1.8 * dt)
        self.boost = clamp(self.boost, -4.0, 8.0)
        drink_speed = 7.0 if self.drink_timer > 0.0 else 0.0
        self.speed_mps = clamp(14.0 + self.distance * 0.0032 + self.boost + drink_speed, 14.0, 50.0)
        self.distance += self.speed_mps * dt
        self.score += int(self.speed_mps * dt * 6.0)
        self.scroll += self.speed_mps * PX_PER_METER * dt

        if self.on_ground:
            self.player_y = self.ground_y(self.player_x) + 34.0
            self.vy = 0.0
            self.rot = 0.0
        else:
            self.airtime += dt
            self.vy -= 1420.0 * dt
            self.player_y += self.vy * dt
            if 276 in self.keys:
                self.player_x = clamp(self.player_x - 90.0 * dt, self.width * 0.20, self.width * 0.38)
            if 275 in self.keys:
                self.player_x = clamp(self.player_x + 90.0 * dt, self.width * 0.20, self.width * 0.38)

            if self.rotate_input():
                self.rot += 540.0 * dt
            else:
                nearest = 360.0 if self.rot > 180.0 else 0.0
                self.rot += clamp(nearest - self.rot, -1.0, 1.0) * 280.0 * dt

            gy = self.ground_y(self.player_x) + 34.0
            if self.player_y <= gy and self.vy < 0.0:
                self.land(gy)

        # Obstacles: fewer and farther apart.
        interval = clamp(1.05 - self.distance / 18000.0, 0.58, 1.05)
        self.spawn_timer -= dt
        while self.spawn_timer <= 0.0:
            self.spawn_obstacle()
            self.spawn_timer += interval * random.uniform(0.95, 1.45)

        # Pickup spawn: coins often, boost occasionally.
        self.coin_timer -= dt
        if self.coin_timer <= 0.0:
            self.spawn_coin_line()
            self.coin_timer = random.uniform(1.0, 1.8)
        self.boost_timer -= dt
        if self.boost_timer <= 0.0:
            self.spawn_boost()
            self.boost_timer = random.uniform(7.0, 12.0)

        move_px = self.speed_mps * PX_PER_METER * dt
        alive = []
        for ob in self.obstacles:
            ob.x -= move_px
            ob.y = self.ground_y(ob.x) + ob.h * 0.42
            if not self.on_ground and abs(ob.x - self.player_x) < 100.0:
                self.airborne_near_ob = True
            if not ob.passed and ob.x + ob.w * 0.5 < self.player_x - 30.0:
                ob.passed = True
                if self.airborne_near_ob:
                    self.add_score(80, "Near miss +80")
                self.airborne_near_ob = False
            if ob.x + ob.w * 0.5 > -140.0:
                alive.append(ob)
        self.obstacles = alive

        alive_items = []
        pw, ph = self.textures["skier"].width * 0.34, self.textures["skier"].height * 0.42
        for it in self.items:
            it.x -= move_px
            if it.kind == "coin":
                it.y += math.sin(self.scroll * 0.02 + it.x * 0.03) * 8.0 * dt
            ihw, ihh = it.w * 0.42, it.h * 0.42
            if overlap(self.player_x, self.player_y, pw, ph, it.x, it.y, ihw, ihh):
                if it.kind == "coin":
                    self.add_score(50, "Coin +50")
                else:
                    self.drink_timer = 4.0
                    if self.yeti_active:
                        self.yeti_x -= 240.0
                    self.add_score(150, "Energy +150")
                continue
            if it.x + it.w * 0.5 > -80.0:
                alive_items.append(it)
        self.items = alive_items

        # Collision with obstacles; a little more forgiving while clearly above them.
        for ob in self.obstacles:
            ohw, ohh = ob.half_size()
            if overlap(self.player_x, self.player_y, pw, ph, ob.x, ob.y, ohw, ohh):
                if not self.on_ground and self.player_y - ph > ob.y + ohh * 0.62:
                    continue
                self.game_over = True
                self.message_text = "GAME OVER\nCrashed into a {}!\nTap or press R to restart".format(ob.kind)
                self.message_color = WHITE
                break

        if self.distance >= YETI_START_DISTANCE and not self.yeti_active:
            self.yeti_active = True
            self.yeti_x = self.player_x - 470.0
            self.yeti_speed = max(17.0, self.speed_mps + 0.8)
            self.add_score(0, "YETI IS COMING!")
        if self.yeti_active:
            enraged = max(0.0, self.distance - YETI_START_DISTANCE) * 0.0012
            self.yeti_speed = max(self.yeti_speed, self.speed_mps + 1.1 + enraged)
            gap_m = (self.player_x - self.yeti_x) / PX_PER_METER
            gap_m -= (self.yeti_speed - self.speed_mps) * dt
            self.yeti_x = self.player_x - gap_m * PX_PER_METER
            if gap_m < 3.2:
                self.game_over = True
                self.message_text = "GAME OVER\nThe Yeti caught you!\nTap or press R to restart"
                self.message_color = WHITE

        if self.action_ttl > 0.0:
            self.action_ttl -= dt
            if self.action_ttl <= 0.0:
                self.action_text = ""

        self._refresh_text()
        self.redraw()

    def land(self, gy):
        self.player_y = gy
        self.on_ground = True
        rot = self.rot % 360.0
        upright = rot < 50.0 or rot > 310.0
        flips = int((self.rot + 50.0) // 360.0)
        if not upright:
            self.game_over = True
            self.message_text = "GAME OVER\nBad landing!\nTap or press R to restart"
            self.message_color = WHITE
            return
        if flips >= 1:
            self.add_score(350 * flips, "Backflip x{} +{}".format(flips, 350 * flips))
        elif self.airtime > 0.35:
            self.add_score(int(self.airtime * 35.0), "Air +{}".format(int(self.airtime * 35.0)))
        self.vy = 0.0
        self.rot = 0.0
        self.airtime = 0.0

    def _refresh_text(self):
        drink = "   Energy {:3.1f}s".format(self.drink_timer) if self.drink_timer > 0.0 else ""
        self.hud_text = "Score {:07d}   Distance {:6.1f} m   Speed {:4.1f} m/s{}".format(
            self.score, self.distance, self.speed_mps, drink
        )
        if self.paused and not self.game_over:
            self.message_text = "PAUSED\nPress P to continue"
            self.message_color = WHITE
        elif not self.game_over:
            if 1700.0 < self.distance < YETI_START_DISTANCE:
                self.message_text = "YETI INCOMING!"
                self.message_color = RED
            elif self.yeti_active:
                gap = max(0.0, (self.player_x - self.yeti_x) / PX_PER_METER)
                self.message_text = "YETI GAP: {:4.1f} m".format(gap)
                self.message_color = RED
            else:
                self.message_text = ""
                self.message_color = WHITE

    def draw_textured(self, tex, cx, cy, angle=0.0):
        if abs(angle) > 0.001:
            PushMatrix()
            Rotate(angle=angle, origin=(cx, cy))
            Rectangle(texture=tex, pos=(cx - tex.width / 2.0, cy - tex.height / 2.0), size=(tex.width, tex.height))
            PopMatrix()
        else:
            Rectangle(texture=tex, pos=(cx - tex.width / 2.0, cy - tex.height / 2.0), size=(tex.width, tex.height))

    def redraw(self):
        w, h = self.width, self.height
        self.canvas.before.clear()
        self.canvas.clear()

        with self.canvas.before:
            Color(*SKY)
            Rectangle(pos=(0, 0), size=(w, h))
            Color(0.72, 0.82, 0.92, 1)
            for i in range(0, w + 260, 260):
                x = i - (self.scroll * 0.16) % 260.0
                Line(points=[x, h * 0.46, x + 130, h * 0.82, x + 260, h * 0.46], width=2)
            Color(*SNOW)
            Rectangle(pos=(0, 0), size=(w, h * 0.42))
            Color(*SNOW_LINE)
            pts = []
            for x in range(-60, int(w) + 120, 40):
                pts.extend([x, self.ground_y(x)])
            if len(pts) >= 4:
                Line(points=pts, width=3)

        with self.canvas:
            for it in self.items:
                Color(1, 1, 1, 1)
                self.draw_textured(it.tex, it.x, it.y)

            if self.yeti_active:
                tex = self.textures["yeti"]
                Color(1, 1, 1, 1)
                self.draw_textured(tex, self.yeti_x, self.ground_y(self.yeti_x) + tex.height * 0.52)

            for ob in self.obstacles:
                Color(1, 1, 1, 1)
                self.draw_textured(ob.tex, ob.x, ob.y)

            tex = self.textures["skier"]
            Color(1, 1, 1, 1)
            self.draw_textured(tex, self.player_x, self.player_y, -self.rot)

            if self.game_over or self.paused:
                Color(*SHADE)
                Rectangle(pos=(0, 0), size=(w, h))


class SkiApp(App):
    def build(self):
        self.title = "Ski Adventure"
        root = FloatLayout()
        self.board = GameBoard()
        root.add_widget(self.board)

        self.hud = Label(
            text="",
            color=HUD,
            font_size="16sp",
            size_hint=(1, None),
            height=34,
            pos_hint={"x": 0, "top": 1},
            halign="left",
            valign="middle",
            padding=(12, 0),
        )
        self.hud.bind(size=self._sync_text_size)
        root.add_widget(self.hud)

        self.action = Label(
            text="",
            color=(0.05, 0.25, 0.55, 1),
            font_size="24sp",
            size_hint=(1, None),
            height=50,
            pos_hint={"x": 0, "top": 0.90},
            halign="center",
            valign="middle",
        )
        self.action.bind(size=self._sync_text_size)
        root.add_widget(self.action)

        self.message = Label(
            text="",
            color=WHITE,
            font_size="30sp",
            size_hint=(1, None),
            height=200,
            pos_hint={"x": 0, "center_y": 0.60},
            halign="center",
            valign="middle",
        )
        self.message.bind(size=self._sync_text_size)
        root.add_widget(self.message)

        Clock.schedule_interval(self.refresh_labels, 1.0 / 30.0)
        return root

    def _sync_text_size(self, inst, size):
        inst.text_size = size

    def refresh_labels(self, dt):
        self.hud.text = self.board.hud_text
        self.action.text = self.board.action_text if self.board.action_ttl > 0.0 else ""
        if self.message.text != self.board.message_text:
            self.message.text = self.board.message_text
        self.message.color = self.board.message_color


if __name__ == "__main__":
    SkiApp().run()
