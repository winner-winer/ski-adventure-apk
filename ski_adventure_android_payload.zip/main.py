# -*- coding: utf-8 -*-
"""Ski Safari style 2D game (Kivy/Android).

Desktop test:
    python3 main.py

Android build:
    buildozer -v android debug

Controls:
  Android: tap = jump; while airborne keep touching to rotate/backflip; release to level for landing.
  Keyboard: Space/Up = jump; hold Up/Space in air = backflip; Left/Right = small air control; R = restart; Esc = quit.
Scoring:
  distance score + jump/airtime + backflip + near-miss bonus. Speed rises with distance.
  After 2000 m the Yeti chases from the left/behind.
"""

import math
import os
import random

from kivy.app import App
from kivy.clock import Clock
from kivy.core.image import Image as CoreImage
from kivy.core.window import Window
from kivy.graphics import Color, Line, PopMatrix, PushMatrix, Rectangle, Rotate
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.widget import Widget

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(BASE_DIR, "assets")
PX_PER_METER = 18.0
YETI_START_DISTANCE = 2000.0

SKY = (170 / 255.0, 220 / 255.0, 245 / 255.0, 1)
SNOW = (245 / 255.0, 250 / 255.0, 255 / 255.0, 1)
SNOW_LINE = (198 / 255.0, 220 / 255.0, 236 / 255.0, 1)
HUD = (20 / 255.0, 30 / 255.0, 45 / 255.0, 1)
RED = (220 / 255.0, 45 / 255.0, 55 / 255.0, 1)
WHITE = (1, 1, 1, 1)
SHADE = (5 / 255.0, 10 / 255.0, 18 / 255.0, 0.62)


def clamp(value, lo, hi):
    return max(lo, min(hi, value))


def load_texture(name):
    return CoreImage(os.path.join(ASSET_DIR, name)).texture


class Obstacle(object):
    __slots__ = ("kind", "tex", "x", "y", "w", "h", "passed")

    def __init__(self, kind, tex, x, y):
        self.kind = kind
        self.tex = tex
        self.x = x
        self.y = y
        self.w = float(tex.width)
        self.h = float(tex.height)
        self.passed = False

    def half_size(self):
        if self.kind == "rock":
            return self.w * 0.42, self.h * 0.38
        return self.w * 0.30, self.h * 0.42


def overlap(ax, ay, ahw, ahh, bx, by, bhw, bhh):
    return abs(ax - bx) < (ahw + bhw) and abs(ay - by) < (ahh + bhh)


class GameBoard(Widget):
    def __init__(self, **kwargs):
        super(GameBoard, self).__init__(**kwargs)
        self.textures = {
            "skier": load_texture("skier.png"),
            "tree": load_texture("tree.png"),
            "rock": load_texture("rock.png"),
            "yeti": load_texture("yeti.png"),
        }
        self.keys = set()
        self.touch = None
        self.bind(size=self._on_size)
        Window.bind(on_key_down=self._on_key_down)
        Window.bind(on_key_up=self._on_key_up)
        self.reset()
        Clock.schedule_interval(self.update, 1.0 / 60.0)

    def _on_size(self, *args):
        self.player_x = self.width * 0.30
        if self.on_ground:
            self.player_y = self.ground_y(self.player_x) + 34.0

    def reset(self):
        w = self.width or Window.width or 360
        h = self.height or Window.height or 640
        self.scroll = 0.0
        self.distance = 0.0
        self.score = 0
        self.speed_mps = 16.0
        self.boost = 0.0
        self.player_x = w * 0.30
        self.player_y = h * 0.55
        self.vy = 0.0
        self.on_ground = True
        self.rot = 0.0
        self.airtime = 0.0
        self.airborne_near_ob = False
        self.obstacles = []
        self.spawn_timer = 0.65
        self.yeti_active = False
        self.yeti_x = -220.0
        self.yeti_speed = 0.0
        self.game_over = False
        self.paused = False
        self.hud_text = ""
        self.message_text = ""
        self.message_color = WHITE
        self.action_text = ""
        self.action_ttl = 0.0

    def _on_key_down(self, window, key, scancode, codepoint, modifiers):
        self.keys.add(key)
        if self.game_over and key == 114:  # R
            self.reset()
        elif key == 112 and not self.game_over:  # P
            self.paused = not self.paused
        elif key in (32, 273) and not self.game_over and not self.paused and self.on_ground:  # Space/Up
            self.jump()
        return True

    def _on_key_up(self, window, key, scancode):
        self.keys.discard(key)
        return True

    def on_touch_down(self, touch):
        if self.game_over:
            self.reset()
            return True
        self.touch = touch
        if self.on_ground and not self.paused:
            self.jump()
        return True

    def on_touch_move(self, touch):
        self.touch = touch
        return True

    def on_touch_up(self, touch):
        if self.touch is touch:
            self.touch = None
        return True

    def ground_y(self, x):
        h = self.height or Window.height or 640
        t = (self.scroll + x) * 0.006
        return h * 0.27 + 44.0 * math.sin(t) + 22.0 * math.sin(t * 0.47 + 1.3)

    def jump(self):
        self.on_ground = False
        self.vy = 620.0
        self.airtime = 0.0
        self.rot = 0.0
        self.airborne_near_ob = False
        self.add_score(10, "Jump +10")

    def add_score(self, points, label):
        self.score += int(points)
        self.action_text = label
        self.action_ttl = 1.2

    def rotate_input(self):
        if self.touch is not None:
            return True
        return (273 in self.keys) or (32 in self.keys)  # Up or Space held

    def spawn_obstacle(self):
        kind = "rock" if random.random() < 0.45 else "tree"
        tex = self.textures[kind]
        x = (self.width or Window.width or 360) + random.uniform(80.0, 180.0)
        y = self.ground_y(x) + tex.height * 0.42
        self.obstacles.append(Obstacle(kind, tex, x, y))

    def update(self, dt):
        dt = min(dt, 1.0 / 20.0)
        if self.game_over or self.paused:
            self._refresh_text()
            self.redraw()
            return

        # Speed keeps rising with distance; Up/Down on the ground still nudge pace.
        if self.on_ground:
            if self.touch is not None:
                if self.touch.y > self.height * 0.72:
                    self.boost += 24.0 * dt
                elif self.touch.y < self.height * 0.24:
                    self.boost -= 34.0 * dt
                else:
                    self.boost *= max(0.0, 1.0 - 1.6 * dt)
            else:
                if 273 in self.keys:
                    self.boost += 24.0 * dt
                elif 274 in self.keys:
                    self.boost -= 34.0 * dt
                else:
                    self.boost *= max(0.0, 1.0 - 1.6 * dt)
        self.boost = clamp(self.boost, -5.0, 10.0)
        self.speed_mps = clamp(16.0 + self.distance * 0.0042 + self.boost, 16.0, 58.0)
        self.distance += self.speed_mps * dt
        self.score += int(self.speed_mps * dt * 6.0)
        self.scroll += self.speed_mps * PX_PER_METER * dt

        # Player physics.
        if self.on_ground:
            self.player_y = self.ground_y(self.player_x) + 34.0
            self.vy = 0.0
            self.rot = 0.0
        else:
            self.airtime += dt
            self.vy -= 1500.0 * dt
            self.player_y += self.vy * dt
            if 276 in self.keys:  # Left: tiny backward air control
                self.player_x = clamp(self.player_x - 90.0 * dt, self.width * 0.22, self.width * 0.38)
            if 275 in self.keys:  # Right
                self.player_x = clamp(self.player_x + 90.0 * dt, self.width * 0.22, self.width * 0.38)

            if self.rotate_input():
                self.rot += 560.0 * dt
            else:
                # If the player lets go mid-flip, drift toward the nearest safe landing angle.
                nearest = 360.0 if self.rot > 180.0 else 0.0
                self.rot += clamp(nearest - self.rot, -1.0, 1.0) * 260.0 * dt

            gy = self.ground_y(self.player_x) + 34.0
            if self.player_y <= gy and self.vy < 0.0:
                self.land(gy)

        # Obstacles come from right to left.
        interval = clamp(0.72 - self.distance / 12000.0, 0.24, 0.72)
        self.spawn_timer -= dt
        while self.spawn_timer <= 0.0:
            self.spawn_obstacle()
            self.spawn_timer += interval * random.uniform(0.75, 1.35)

        move_px = self.speed_mps * PX_PER_METER * dt
        alive = []
        for ob in self.obstacles:
            ob.x -= move_px
            ob.y = self.ground_y(ob.x) + ob.h * 0.42
            if not self.on_ground and abs(ob.x - self.player_x) < 95.0:
                self.airborne_near_ob = True
            if not ob.passed and ob.x + ob.w * 0.5 < self.player_x - 28.0:
                ob.passed = True
                if self.airborne_near_ob:
                    self.add_score(80, "Near miss +80")
                self.airborne_near_ob = False
            if ob.x + ob.w * 0.5 > -120.0:
                alive.append(ob)
        self.obstacles = alive

        # Collision with trees/rocks.
        pw, ph = self.textures["skier"].width * 0.30, self.textures["skier"].height * 0.38
        for ob in self.obstacles:
            ohw, ohh = ob.half_size()
            if overlap(self.player_x, self.player_y, pw, ph, ob.x, ob.y, ohw, ohh):
                # If clearly above a rock/tree crown during a jump, do not count as a crash.
                if not self.on_ground and self.player_y - ph > ob.y + ohh * 0.55:
                    continue
                self.game_over = True
                self.message_text = "GAME OVER\nCrashed into a {}!\nTap or press R to restart".format(ob.kind)
                self.message_color = WHITE
                break

        # Yeti chase from the left/behind after 2000 m.
        if self.distance >= YETI_START_DISTANCE and not self.yeti_active:
            self.yeti_active = True
            self.yeti_x = self.player_x - 360.0
            self.yeti_speed = max(18.0, self.speed_mps + 1.0)
            self.add_score(0, "YETI IS COMING!")
        if self.yeti_active:
            enraged = max(0.0, self.distance - YETI_START_DISTANCE) * 0.0018
            self.yeti_speed = max(self.yeti_speed, self.speed_mps + 1.6 + enraged)
            gap_m = (self.player_x - self.yeti_x) / PX_PER_METER
            gap_m -= (self.yeti_speed - self.speed_mps) * dt
            self.yeti_x = self.player_x - gap_m * PX_PER_METER
            if gap_m < 3.0:
                self.game_over = True
                self.message_text = "GAME OVER\nThe Yeti caught you!\nTap or press R to restart"
                self.message_color = WHITE

        if self.action_ttl > 0.0:
            self.action_ttl -= dt
            if self.action_ttl <= 0.0:
                self.action_text = ""

        self._refresh_text()
        self.redraw()

    def land(self, gy):
        self.player_y = gy
        self.on_ground = True
        rot = self.rot % 360.0
        upright = rot < 45.0 or rot > 315.0
        flips = int((self.rot + 45.0) // 360.0)
        if not upright:
            self.game_over = True
            self.message_text = "GAME OVER\nBad landing!\nTap or press R to restart"
            self.message_color = WHITE
            return
        if flips >= 1:
            self.add_score(350 * flips, "Backflip x{} +{}".format(flips, 350 * flips))
        elif self.airtime > 0.35:
            self.add_score(int(self.airtime * 35.0), "Air +{}".format(int(self.airtime * 35.0)))
        self.vy = 0.0
        self.rot = 0.0
        self.airtime = 0.0

    def _refresh_text(self):
        self.hud_text = "Score {:07d}   Distance {:6.1f} m   Speed {:4.1f} m/s".format(
            self.score, self.distance, self.speed_mps
        )
        if self.paused and not self.game_over:
            self.message_text = "PAUSED\nPress P to continue"
            self.message_color = WHITE
        elif not self.game_over:
            if 1700.0 < self.distance < YETI_START_DISTANCE:
                self.message_text = "YETI INCOMING!"
                self.message_color = RED
            elif self.yeti_active:
                gap = max(0.0, (self.player_x - self.yeti_x) / PX_PER_METER)
                self.message_text = "YETI GAP: {:4.1f} m".format(gap)
                self.message_color = RED
            else:
                self.message_text = ""
                self.message_color = WHITE

    def draw_textured(self, tex, cx, cy, angle=0.0):
        if abs(angle) > 0.001:
            PushMatrix()
            Rotate(angle=angle, origin=(cx, cy))
            Rectangle(texture=tex, pos=(cx - tex.width / 2.0, cy - tex.height / 2.0), size=(tex.width, tex.height))
            PopMatrix()
        else:
            Rectangle(texture=tex, pos=(cx - tex.width / 2.0, cy - tex.height / 2.0), size=(tex.width, tex.height))

    def redraw(self):
        w, h = self.width, self.height
        self.canvas.before.clear()
        self.canvas.clear()

        with self.canvas.before:
            Color(*SKY)
            Rectangle(pos=(0, 0), size=(w, h))
            # distant mountains
            Color(0.72, 0.82, 0.92, 1)
            for i in range(0, w + 220, 220):
                x = i - (self.scroll * 0.18) % 220.0
                Line(points=[x, h * 0.42, x + 110, h * 0.72, x + 220, h * 0.42], width=2)
            # snow ground polygon approximation
            Color(*SNOW)
            Rectangle(pos=(0, 0), size=(w, h * 0.36))
            Color(*SNOW_LINE)
            pts = []
            for x in range(-40, int(w) + 80, 40):
                pts.extend([x, self.ground_y(x)])
            if len(pts) >= 4:
                Line(points=pts, width=3)

        with self.canvas:
            if self.yeti_active:
                tex = self.textures["yeti"]
                Color(1, 1, 1, 1)
                self.draw_textured(tex, self.yeti_x, self.ground_y(self.yeti_x) + tex.height * 0.52)

            for ob in self.obstacles:
                Color(1, 1, 1, 1)
                self.draw_textured(ob.tex, ob.x, ob.y)

            tex = self.textures["skier"]
            Color(1, 1, 1, 1)
            self.draw_textured(tex, self.player_x, self.player_y, -self.rot)

            if self.game_over or self.paused:
                Color(*SHADE)
                Rectangle(pos=(0, 0), size=(w, h))


class SkiApp(App):
    def build(self):
        self.title = "Ski Adventure"
        root = FloatLayout()
        self.board = GameBoard()
        root.add_widget(self.board)

        self.hud = Label(
            text="",
            color=HUD,
            font_size="16sp",
            size_hint=(1, None),
            height=38,
            pos_hint={"x": 0, "top": 1},
            halign="left",
            valign="middle",
            padding=(12, 0),
        )
        self.hud.bind(size=self._sync_text_size)
        root.add_widget(self.hud)

        self.action = Label(
            text="",
            color=(0.05, 0.25, 0.55, 1),
            font_size="24sp",
            size_hint=(1, None),
            height=54,
            pos_hint={"x": 0, "top": 0.92},
            halign="center",
            valign="middle",
        )
        self.action.bind(size=self._sync_text_size)
        root.add_widget(self.action)

        self.message = Label(
            text="",
            color=WHITE,
            font_size="30sp",
            size_hint=(1, None),
            height=220,
            pos_hint={"x": 0, "center_y": 0.62},
            halign="center",
            valign="middle",
        )
        self.message.bind(size=self._sync_text_size)
        root.add_widget(self.message)

        Clock.schedule_interval(self.refresh_labels, 1.0 / 30.0)
        return root

    def _sync_text_size(self, inst, size):
        inst.text_size = size

    def refresh_labels(self, dt):
        self.hud.text = self.board.hud_text
        self.action.text = self.board.action_text if self.board.action_ttl > 0.0 else ""
        if self.message.text != self.board.message_text:
            self.message.text = self.board.message_text
        self.message.color = self.board.message_color


if __name__ == "__main__":
    SkiApp().run()
