# -*- coding: utf-8 -*-
"""Ski Safari style 2D game (Kivy/Android), landscape + mounts + shield.

Feel update:
- Visible slope always goes from upper-left to lower-right; no uphill climb on screen.
- Jump buffer + coyote time for responsive input.
- Skier aligns to slope on the ground; landing is judged relative to slope angle.
- Releasing flip input auto-levels toward the nearest safe landing angle.
"""

import math
import os
import random

from kivy.app import App
from kivy.clock import Clock
from kivy.core.image import Image as CoreImage
from kivy.core.window import Window
from kivy.graphics import Color, Line, Mesh, PopMatrix, PushMatrix, Rectangle, Rotate
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.widget import Widget

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(BASE_DIR, "assets")
PX_PER_METER = 18.0
YETI_START_DISTANCE = 2000.0

SKY = (170 / 255.0, 220 / 255.0, 245 / 255.0, 1)
SNOW = (245 / 255.0, 250 / 255.0, 255 / 255.0, 1)
SNOW_LINE = (198 / 255.0, 220 / 255.0, 236 / 255.0, 1)
HUD = (20 / 255.0, 30 / 255.0, 45 / 255.0, 1)
RED = (220 / 255.0, 45 / 255.0, 55 / 255.0, 1)
WHITE = (1, 1, 1, 1)
SHADE = (5 / 255.0, 10 / 255.0, 18 / 255.0, 0.62)


def clamp(value, lo, hi):
    return max(lo, min(hi, value))


def load_texture(name):
    return CoreImage(os.path.join(ASSET_DIR, name)).texture


class Obstacle(object):
    __slots__ = ("kind", "tex", "x", "y", "w", "h", "passed")

    def __init__(self, kind, tex, x, y):
        self.kind = kind
        self.tex = tex
        self.x = x
        self.y = y
        self.w = float(tex.width)
        self.h = float(tex.height)
        self.passed = False

    def half_size(self):
        if self.kind == "rock":
            return self.w * 0.42, self.h * 0.36
        return self.w * 0.28, self.h * 0.40


class Pickup(object):
    __slots__ = ("kind", "tex", "x", "y", "w", "h")

    def __init__(self, kind, tex, x, y):
        self.kind = kind
        self.tex = tex
        self.x = x
        self.y = y
        self.w = float(tex.width)
        self.h = float(tex.height)


def overlap(ax, ay, ahw, ahh, bx, by, bhw, bhh):
    return abs(ax - bx) < (ahw + bhw) and abs(ay - by) < (ahh + bhh)


class GameBoard(Widget):
    def __init__(self, **kwargs):
        super(GameBoard, self).__init__(**kwargs)
        self.textures = {
            "skier": load_texture("skier.png"),
            "tree": load_texture("tree.png"),
            "rock": load_texture("rock.png"),
            "yeti": load_texture("yeti.png"),
            "coin": load_texture("coin.png"),
            "boost": load_texture("boost.png"),
            "shield": load_texture("shield.png"),
            "penguin": load_texture("penguin.png"),
            "eagle": load_texture("eagle.png"),
            "snowmobile": load_texture("snowmobile.png"),
        }
        bg_path = os.path.join(ASSET_DIR, "bg.jpg")
        self.bg = CoreImage(bg_path).texture if os.path.exists(bg_path) else None
        self.keys = set()
        self.touch = None
        self.bind(size=self._on_size)
        Window.bind(on_key_down=self._on_key_down)
        Window.bind(on_key_up=self._on_key_up)
        self.reset()
        Clock.schedule_interval(self.update, 1.0 / 60.0)

    def _on_size(self, *args):
        self.player_x = self.width * 0.28
        if self.on_ground:
            self.player_y = self.ground_y(self.player_x) + 34.0

    def reset(self):
        w = self.width or Window.width or 640
        h = self.height or Window.height or 360
        self.scroll = 0.0
        self.distance = 0.0
        self.score = 0
        self.speed_mps = 21.0
        self.boost = 0.0
        self.drink_timer = 0.0
        self.player_x = w * 0.28
        self.player_y = h * 0.62
        self.vy = 0.0
        self.on_ground = True
        self.rot = 0.0
        self.takeoff_rot = 0.0
        self.jump_buffer = 0.0
        self.coyote = 0.0
        self.airtime = 0.0
        self.airborne_near_ob = False
        self.obstacles = []
        self.items = []
        self.spawn_timer = 1.0
        self.coin_timer = 0.4
        self.boost_timer = 5.0
        self.shield_timer = 6.0
        self.mount_timer_spawn = 8.0
        self.shield_charges = 0
        self.mount = None
        self.mount_timer = 0.0
        self.mount_hits = 0
        self.yeti_active = False
        self.yeti_x = -300.0
        self.yeti_speed = 0.0
        self.game_over = False
        self.paused = False
        self.hud_text = ""
        self.message_text = ""
        self.message_color = WHITE
        self.action_text = ""
        self.action_ttl = 0.0

    def _on_key_down(self, window, key, scancode, codepoint, modifiers):
        self.keys.add(key)
        if self.game_over and key == 114:
            self.reset()
        elif key == 112 and not self.game_over:
            self.paused = not self.paused
        elif key in (32, 273) and not self.game_over and not self.paused:
            self.jump_buffer = 0.13
        return True

    def _on_key_up(self, window, key, scancode):
        self.keys.discard(key)
        return True

    def on_touch_down(self, touch):
        if self.game_over:
            self.reset()
            return True
        self.touch = touch
        if not self.paused:
            self.jump_buffer = 0.13
        return True

    def on_touch_move(self, touch):
        self.touch = touch
        return True

    def on_touch_up(self, touch):
        if self.touch is touch:
            self.touch = None
        return True

    def ground_y(self, x):
        """Always downhill on screen: left higher, right lower; only smooth waves."""
        h = self.height or Window.height or 360
        pos = self.scroll + x
        base = h * 0.68 - x * 0.060
        return base + 12.0 * math.sin(pos * 0.0042) + 7.0 * math.sin(pos * 0.010 + 1.4)

    def slope_angle_rot(self, x):
        dy = self.ground_y(x + 12.0) - self.ground_y(x - 12.0)
        slope_deg = math.degrees(math.atan2(dy, 24.0))
        return -slope_deg

    def jump(self):
        self.on_ground = False
        self.coyote = 0.0
        self.vy = 625.0
        self.airtime = 0.0
        self.takeoff_rot = self.rot
        self.airborne_near_ob = False
        self.add_score(10, "Jump +10")

    def add_score(self, points, label):
        self.score += int(points)
        self.action_text = label
        self.action_ttl = 1.2

    def rotate_input(self):
        if self.touch is not None:
            return True
        return (273 in self.keys) or (32 in self.keys)

    def mount_speed(self):
        if self.mount == "penguin":
            return 3.0
        if self.mount == "eagle" and self.mount_timer > 0.0:
            return 1.0
        if self.mount == "snowmobile" and self.mount_timer > 0.0:
            return 9.0
        return 0.0

    def spawn_obstacle(self):
        kind = "rock" if random.random() < 0.48 else "tree"
        tex = self.textures[kind]
        w = self.width or Window.width or 640
        rightmost = max([ob.x for ob in self.obstacles], default=0.0)
        x = max(w + random.uniform(190.0, 300.0), rightmost + random.uniform(500.0, 760.0))
        y = self.ground_y(x) + tex.height * 0.42
        self.obstacles.append(Obstacle(kind, tex, x, y))

    def spawn_coin_line(self):
        tex = self.textures["coin"]
        w = self.width or Window.width or 640
        start = w + random.uniform(80.0, 180.0)
        for i in range(5):
            x = start + i * 46.0
            y = self.ground_y(x) + 100.0 + 22.0 * math.sin(i * 0.9)
            self.items.append(Pickup("coin", tex, x, y))

    def spawn_boost(self):
        tex = self.textures["boost"]
        w = self.width or Window.width or 640
        x = w + random.uniform(200.0, 340.0)
        y = self.ground_y(x) + 122.0
        self.items.append(Pickup("boost", tex, x, y))

    def spawn_shield(self):
        tex = self.textures["shield"]
        w = self.width or Window.width or 640
        x = w + random.uniform(240.0, 420.0)
        y = self.ground_y(x) + 136.0
        self.items.append(Pickup("shield", tex, x, y))

    def spawn_mount(self):
        choices = ["penguin"]
        if self.distance > 700.0:
            choices += ["eagle", "penguin"]
        if self.distance > 1500.0:
            choices += ["snowmobile", "eagle", "penguin"]
        kind = random.choice(choices)
        tex = self.textures[kind]
        w = self.width or Window.width or 640
        x = w + random.uniform(260.0, 460.0)
        y = self.ground_y(x) + 112.0
        self.items.append(Pickup(kind, tex, x, y))

    def absorb_hit(self, ob):
        if self.shield_charges > 0:
            self.shield_charges -= 1
            self.add_score(0, "Shield -1")
            return True
        if self.mount == "snowmobile" and self.mount_timer > 0.0 and ob.kind == "rock":
            self.add_score(120, "Smashed rock +120")
            return True
        if self.mount and self.mount_hits > 0:
            self.mount_hits -= 1
            self.add_score(0, self.mount.capitalize() + " -1 hit")
            if self.mount == "penguin":
                self.mount = None
                self.mount_hits = 0
            elif self.mount_hits <= 0:
                self.mount = None
                self.mount_timer = 0.0
            return True
        return False

    def absorb_bad_landing(self, slope_ref):
        if self.shield_charges > 0:
            self.shield_charges -= 1
            self.add_score(0, "Shield saved landing")
            self.rot = slope_ref
            return True
        if self.mount and self.mount_hits > 0:
            self.mount_hits -= 1
            self.add_score(0, self.mount.capitalize() + " saved landing")
            if self.mount == "penguin" or self.mount_hits <= 0:
                self.mount = None
                self.mount_hits = 0
                self.mount_timer = 0.0
            self.rot = slope_ref
            return True
        return False

    def update(self, dt):
        dt = min(dt, 1.0 / 20.0)
        if self.game_over or self.paused:
            self._refresh_text()
            self.redraw()
            return

        if self.jump_buffer > 0.0:
            self.jump_buffer = max(0.0, self.jump_buffer - dt)
        if self.drink_timer > 0.0:
            self.drink_timer = max(0.0, self.drink_timer - dt)
        if self.mount in ("eagle", "snowmobile") and self.mount_timer > 0.0:
            self.mount_timer = max(0.0, self.mount_timer - dt)
            if self.mount_timer <= 0.0:
                if self.mount == "eagle":
                    self.vy = min(self.vy, 0.0)
                self.mount = None
                self.mount_hits = 0

        if self.on_ground:
            self.coyote = 0.11
            if self.touch is not None:
                if self.touch.y > self.height * 0.72:
                    self.boost += 23.0 * dt
                elif self.touch.y < self.height * 0.24:
                    self.boost -= 30.0 * dt
                else:
                    self.boost *= max(0.0, 1.0 - 1.8 * dt)
            else:
                if 273 in self.keys:
                    self.boost += 23.0 * dt
                elif 274 in self.keys:
                    self.boost -= 30.0 * dt
                else:
                    self.boost *= max(0.0, 1.0 - 1.8 * dt)
        else:
            self.coyote = max(0.0, self.coyote - dt)
        self.boost = clamp(self.boost, -4.0, 9.0)
        drink_speed = 7.0 if self.drink_timer > 0.0 else 0.0
        self.speed_mps = clamp(21.0 + self.distance * 0.0035 + self.boost + drink_speed + self.mount_speed(), 21.0, 64.0)
        self.distance += self.speed_mps * dt
        self.score += int(self.speed_mps * dt * 6.0)
        self.scroll += self.speed_mps * PX_PER_METER * dt

        if self.jump_buffer > 0.0 and (self.on_ground or self.coyote > 0.0):
            self.jump_buffer = 0.0
            self.jump()

        eagle_fly = self.mount == "eagle" and self.mount_timer > 0.0
        if eagle_fly:
            self.on_ground = False
            self.airtime += dt
            if self.rotate_input():
                self.vy = clamp(self.vy + 1000.0 * dt, -430.0, 580.0)
                self.rot += 540.0 * dt
            else:
                self.vy = clamp(self.vy - 560.0 * dt, -540.0, 580.0)
                target = self.takeoff_rot + round((self.rot - self.takeoff_rot) / 360.0) * 360.0
                self.rot += clamp(target - self.rot, -1.0, 1.0) * 340.0 * dt
            min_y = self.ground_y(self.player_x) + 122.0
            self.player_y = clamp(self.player_y + self.vy * dt, min_y, self.height * 0.94)
        elif self.on_ground:
            self.player_y = self.ground_y(self.player_x) + 34.0
            self.vy = 0.0
            target = self.slope_angle_rot(self.player_x) - self.boost * 1.1
            self.rot += clamp(target - self.rot, -1.0, 1.0) * min(1.0, 12.0 * dt)
        else:
            self.airtime += dt
            self.vy -= 1450.0 * dt
            self.player_y += self.vy * dt
            if 276 in self.keys:
                self.player_x = clamp(self.player_x - 110.0 * dt, self.width * 0.20, self.width * 0.38)
            if 275 in self.keys:
                self.player_x = clamp(self.player_x + 110.0 * dt, self.width * 0.20, self.width * 0.38)
            if self.rotate_input():
                self.rot += 560.0 * dt
            else:
                target = self.takeoff_rot + round((self.rot - self.takeoff_rot) / 360.0) * 360.0
                self.rot += clamp(target - self.rot, -1.0, 1.0) * 340.0 * dt
            gy = self.ground_y(self.player_x) + 34.0
            if self.player_y <= gy and self.vy < 0.0:
                self.land(gy)

        interval = clamp(1.16 - self.distance / 22000.0, 0.66, 1.16)
        self.spawn_timer -= dt
        while self.spawn_timer <= 0.0:
            self.spawn_obstacle()
            self.spawn_timer += interval * random.uniform(1.05, 1.65)

        self.coin_timer -= dt
        if self.coin_timer <= 0.0:
            self.spawn_coin_line()
            self.coin_timer = random.uniform(0.85, 1.5)
        self.boost_timer -= dt
        if self.boost_timer <= 0.0:
            self.spawn_boost()
            self.boost_timer = random.uniform(6.5, 11.0)
        if self.distance > 400.0:
            self.shield_timer -= dt
            if self.shield_timer <= 0.0:
                self.spawn_shield()
                self.shield_timer = random.uniform(8.0, 13.0)
        self.mount_timer_spawn -= dt
        if self.mount_timer_spawn <= 0.0:
            self.spawn_mount()
            self.mount_timer_spawn = random.uniform(10.0, 16.0)

        move_px = self.speed_mps * PX_PER_METER * dt
        alive = []
        for ob in self.obstacles:
            ob.x -= move_px
            ob.y = self.ground_y(ob.x) + ob.h * 0.42
            if not self.on_ground and abs(ob.x - self.player_x) < 100.0:
                self.airborne_near_ob = True
            if not ob.passed and ob.x + ob.w * 0.5 < self.player_x - 30.0:
                ob.passed = True
                if self.airborne_near_ob:
                    self.add_score(80, "Near miss +80")
                self.airborne_near_ob = False
            if ob.x + ob.w * 0.5 > -1000.0:
                alive.append(ob)
        self.obstacles = alive

        alive_items = []
        pw, ph = self.textures["skier"].width * 0.34, self.textures["skier"].height * 0.42
        for it in self.items:
            it.x -= move_px
            if it.kind == "coin":
                it.y += math.sin(self.scroll * 0.02 + it.x * 0.03) * 8.0 * dt
            ihw, ihh = it.w * 0.44, it.h * 0.44
            if overlap(self.player_x, self.player_y, pw, ph, it.x, it.y, ihw, ihh):
                if it.kind == "coin":
                    self.add_score(50, "Coin +50")
                elif it.kind == "boost":
                    self.drink_timer = 4.0
                    if self.yeti_active:
                        self.yeti_x -= 240.0
                    self.add_score(150, "Energy +150")
                elif it.kind == "shield":
                    self.shield_charges = min(4, self.shield_charges + 2)
                    self.add_score(100, "Shield +2")
                elif it.kind == "penguin":
                    self.mount = "penguin"
                    self.mount_timer = 0.0
                    self.mount_hits = 1
                    self.add_score(200, "Penguin ride +200")
                elif it.kind == "eagle":
                    self.mount = "eagle"
                    self.mount_timer = 8.0
                    self.mount_hits = 999
                    self.vy = max(self.vy, 260.0)
                    self.add_score(250, "Eagle ride +250")
                elif it.kind == "snowmobile":
                    self.mount = "snowmobile"
                    self.mount_timer = 14.0
                    self.mount_hits = 4
                    self.add_score(300, "Snowmobile +300")
                continue
            if it.x + it.w * 0.5 > -90.0:
                alive_items.append(it)
        self.items = alive_items

        if not eagle_fly:
            for ob in self.obstacles:
                ohw, ohh = ob.half_size()
                if overlap(self.player_x, self.player_y, pw, ph, ob.x, ob.y, ohw, ohh):
                    if not self.on_ground and self.player_y - ph > ob.y + ohh * 0.62:
                        continue
                    if self.absorb_hit(ob):
                        ob.x = -10000.0
                        continue
                    self.game_over = True
                    self.message_text = "GAME OVER\nCrashed into a {}!\nTap or press R to restart".format(ob.kind)
                    self.message_color = WHITE
                    break
            self.obstacles = [ob for ob in self.obstacles if ob.x > -900.0]

        if self.distance >= YETI_START_DISTANCE and not self.yeti_active:
            self.yeti_active = True
            self.yeti_x = self.player_x - 560.0
            self.yeti_speed = max(20.0, self.speed_mps + 0.8)
            self.add_score(0, "YETI IS COMING!")
        if self.yeti_active:
            enraged = max(0.0, self.distance - YETI_START_DISTANCE) * 0.0010
            self.yeti_speed = max(self.yeti_speed, self.speed_mps + 1.0 + enraged)
            gap_m = (self.player_x - self.yeti_x) / PX_PER_METER
            gap_m -= (self.yeti_speed - self.speed_mps) * dt
            self.yeti_x = self.player_x - gap_m * PX_PER_METER
            if gap_m < 3.4:
                self.game_over = True
                self.message_text = "GAME OVER\nThe Yeti caught you!\nTap or press R to restart"
                self.message_color = WHITE

        if self.action_ttl > 0.0:
            self.action_ttl -= dt
            if self.action_ttl <= 0.0:
                self.action_text = ""

        self._refresh_text()
        self.redraw()

    def land(self, gy):
        self.player_y = gy
        self.on_ground = True
        slope_ref = self.slope_angle_rot(self.player_x)
        rel = self.rot - self.takeoff_rot
        diff = (rel - round(rel / 360.0) * 360.0 + 180.0) % 360.0 - 180.0
        upright = abs(diff) < 58.0
        flips = int((rel + 58.0) // 360.0)
        if not upright and not self.absorb_bad_landing(slope_ref):
            self.game_over = True
            self.message_text = "GAME OVER\nBad landing!\nTap or press R to restart"
            self.message_color = WHITE
            return
        if flips >= 1:
            self.add_score(350 * flips, "Backflip x{} +{}".format(flips, 350 * flips))
        elif self.airtime > 0.35:
            self.add_score(int(self.airtime * 35.0), "Air +{}".format(int(self.airtime * 35.0)))
        self.vy = 0.0
        self.rot = slope_ref
        self.airtime = 0.0

    def _refresh_text(self):
        parts = [
            "Score {:07d}".format(self.score),
            "Distance {:6.1f} m".format(self.distance),
            "Speed {:4.1f} m/s".format(self.speed_mps),
        ]
        if self.shield_charges > 0:
            parts.append("Shield x{}".format(self.shield_charges))
        if self.mount:
            if self.mount in ("eagle", "snowmobile"):
                parts.append("{} {:3.1f}s".format(self.mount.capitalize(), self.mount_timer))
            else:
                parts.append("Penguin x{}".format(self.mount_hits))
        if self.drink_timer > 0.0:
            parts.append("Energy {:3.1f}s".format(self.drink_timer))
        self.hud_text = "   ".join(parts)
        if self.paused and not self.game_over:
            self.message_text = "PAUSED\nPress P to continue"
            self.message_color = WHITE
        elif not self.game_over:
            if 1700.0 < self.distance < YETI_START_DISTANCE:
                self.message_text = "YETI INCOMING!"
                self.message_color = RED
            elif self.yeti_active:
                gap = max(0.0, (self.player_x - self.yeti_x) / PX_PER_METER)
                self.message_text = "YETI GAP: {:4.1f} m".format(gap)
                self.message_color = RED
            else:
                self.message_text = ""
                self.message_color = WHITE

    def draw_textured(self, tex, cx, cy, angle=0.0):
        if abs(angle) > 0.001:
            PushMatrix()
            Rotate(angle=angle, origin=(cx, cy))
            Rectangle(texture=tex, pos=(cx - tex.width / 2.0, cy - tex.height / 2.0), size=(tex.width, tex.height))
            PopMatrix()
        else:
            Rectangle(texture=tex, pos=(cx - tex.width / 2.0, cy - tex.height / 2.0), size=(tex.width, tex.height))

    def redraw(self):
        w, h = self.width, self.height
        self.canvas.before.clear()
        self.canvas.clear()

        with self.canvas.before:
            if self.bg is not None:
                Color(1, 1, 1, 1)
                Rectangle(texture=self.bg, pos=(0, 0), size=(w, h))
                Color(1, 1, 1, 0.16)
                Rectangle(pos=(0, 0), size=(w, h))
            else:
                Color(*SKY)
                Rectangle(pos=(0, 0), size=(w, h))

            Color(*SNOW)
            vertices = []
            x = -80.0
            while x <= w + 80.0:
                vertices.extend([x, self.ground_y(x)])
                x += 40.0
            vertices.extend([w + 80.0, 0.0, -80.0, 0.0])
            count = len(vertices) // 2
            Mesh(vertices=vertices, indices=list(range(count)), mode="triangle_fan")
            Color(*SNOW_LINE)
            pts = []
            for xx in range(-80, int(w) + 120, 40):
                pts.extend([xx, self.ground_y(xx)])
            if len(pts) >= 4:
                Line(points=pts, width=3)

        with self.canvas:
            for it in self.items:
                Color(1, 1, 1, 1)
                self.draw_textured(it.tex, it.x, it.y)

            if self.yeti_active:
                tex = self.textures["yeti"]
                Color(1, 1, 1, 1)
                self.draw_textured(tex, self.yeti_x, self.ground_y(self.yeti_x) + tex.height * 0.52)

            for ob in self.obstacles:
                Color(1, 1, 1, 1)
                self.draw_textured(ob.tex, ob.x, ob.y)

            tex = self.textures["skier"]
            Color(1, 1, 1, 1)
            self.draw_textured(tex, self.player_x, self.player_y, -self.rot)

            if self.game_over or self.paused:
                Color(*SHADE)
                Rectangle(pos=(0, 0), size=(w, h))


class SkiApp(App):
    def build(self):
        self.title = "Ski Adventure"
        root = FloatLayout()
        self.board = GameBoard()
        root.add_widget(self.board)

        self.hud = Label(
            text="",
            color=HUD,
            font_size="16sp",
            size_hint=(1, None),
            height=34,
            pos_hint={"x": 0, "top": 1},
            halign="left",
            valign="middle",
            padding=(12, 0),
        )
        self.hud.bind(size=self._sync_text_size)
        root.add_widget(self.hud)

        self.action = Label(
            text="",
            color=(0.05, 0.25, 0.55, 1),
            font_size="24sp",
            size_hint=(1, None),
            height=50,
            pos_hint={"x": 0, "top": 0.90},
            halign="center",
            valign="middle",
        )
        self.action.bind(size=self._sync_text_size)
        root.add_widget(self.action)

        self.message = Label(
            text="",
            color=WHITE,
            font_size="30sp",
            size_hint=(1, None),
            height=200,
            pos_hint={"x": 0, "center_y": 0.60},
            halign="center",
            valign="middle",
        )
        self.message.bind(size=self._sync_text_size)
        root.add_widget(self.message)

        Clock.schedule_interval(self.refresh_labels, 1.0 / 30.0)
        return root

    def _sync_text_size(self, inst, size):
        inst.text_size = size

    def refresh_labels(self, dt):
        self.hud.text = self.board.hud_text
        self.action.text = self.board.action_text if self.board.action_ttl > 0.0 else ""
        if self.message.text != self.board.message_text:
            self.message.text = self.board.message_text
        self.message.color = self.board.message_color


if __name__ == "__main__":
    SkiApp().run()
