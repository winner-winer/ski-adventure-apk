# -*- coding: utf-8 -*-
"""Kivy/Android version of 2D Ski Adventure.

Desktop test:
    python3 main.py

Android build:
    buildozer -v android debug

Controls on desktop: Left/Right steer, Up accelerate, Down brake, P pause, R restart.
Controls on Android: drag/touch left or right of the skier to steer; touch near the
top of the screen to accelerate, near the bottom to brake; tap after game over to restart.
"""

import os
import random

from kivy.app import App
from kivy.clock import Clock
from kivy.core.image import Image as CoreImage
from kivy.core.window import Window
from kivy.graphics import Color, Line, Rectangle
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.label import Label
from kivy.uix.widget import Widget

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ASSET_DIR = os.path.join(BASE_DIR, "assets")
PX_PER_METER = 13.0
YETI_START_DISTANCE = 2000.0

SNOW = (245 / 255.0, 250 / 255.0, 255 / 255.0, 1)
SNOW_LINE = (210 / 255.0, 226 / 255.0, 240 / 255.0, 1)
SIDE_LINE = (190 / 255.0, 214 / 255.0, 232 / 255.0, 1)
HUD = (25 / 255.0, 35 / 255.0, 50 / 255.0, 1)
RED = (220 / 255.0, 50 / 255.0, 60 / 255.0, 1)
WHITE = (1, 1, 1, 1)
SHADE = (8 / 255.0, 12 / 255.0, 20 / 255.0, 0.58)


def clamp(value, lo, hi):
    return max(lo, min(hi, value))


def load_texture(name):
    return CoreImage(os.path.join(ASSET_DIR, name)).texture


class Obstacle(object):
    __slots__ = ("kind", "tex", "x", "y", "w", "h")

    def __init__(self, kind, tex, x, y):
        self.kind = kind
        self.tex = tex
        self.x = x
        self.y = y
        self.w = float(tex.width)
        self.h = float(tex.height)

    def half_size(self):
        if self.kind == "rock":
            return self.w * 0.40, self.h * 0.34
        return self.w * 0.26, self.h * 0.36


def overlap(ax, ay, ahw, ahh, bx, by, bhw, bhh):
    return abs(ax - bx) < (ahw + bhw) and abs(ay - by) < (ahh + bhh)


class GameBoard(Widget):
    def __init__(self, **kwargs):
        super(GameBoard, self).__init__(**kwargs)
        self.textures = {
            "skier": load_texture("skier.png"),
            "tree": load_texture("tree.png"),
            "rock": load_texture("rock.png"),
            "yeti": load_texture("yeti.png"),
        }
        self.keys = set()
        self.touch = None
        self.bind(size=self._on_size)
        Window.bind(on_key_down=self._on_key_down)
        Window.bind(on_key_up=self._on_key_up)
        self.reset()
        Clock.schedule_interval(self.update, 1.0 / 60.0)

    def _on_size(self, *args):
        self.player_y = self.height * 0.60
        self.player_x = clamp(self.player_x, 28.0, max(28.0, self.width - 28.0))

    def reset(self):
        w = self.width or Window.width or 360
        h = self.height or Window.height or 640
        self.player_x = w * 0.5
        self.player_y = h * 0.60
        self.player_vx = 0.0
        self.boost = 0.0
        self.speed_mps = 22.0
        self.distance = 0.0
        self.score = 0
        self.obstacles = []
        self.spawn_timer = 0.45
        self.yeti_active = False
        self.yeti_x = self.player_x
        self.yeti_y = h + 220.0
        self.yeti_speed = 0.0
        self.game_over = False
        self.paused = False
        self.hud_text = ""
        self.message_text = ""
        self.message_color = WHITE

    def _on_key_down(self, window, key, scancode, codepoint, modifiers):
        self.keys.add(key)
        if self.game_over and key == 114:  # R
            self.reset()
        elif key == 112 and not self.game_over:  # P
            self.paused = not self.paused
        return True

    def _on_key_up(self, window, key, scancode):
        self.keys.discard(key)
        return True

    def on_touch_down(self, touch):
        if self.game_over:
            self.reset()
            return True
        self.touch = touch
        return True

    def on_touch_move(self, touch):
        self.touch = touch
        return True

    def on_touch_up(self, touch):
        if self.touch is touch:
            self.touch = None
        return True

    def _input_state(self):
        kb_steer = (1 if 275 in self.keys else 0) - (1 if 276 in self.keys else 0)
        kb_up = 273 in self.keys
        kb_down = 274 in self.keys

        touch_steer = 0.0
        touch_up = False
        touch_down = False
        if self.touch is not None:
            touch_steer = clamp((self.touch.x - self.player_x) / 140.0, -1.0, 1.0)
            touch_up = self.touch.y > self.height * 0.72
            touch_down = self.touch.y < self.height * 0.28

        return clamp(kb_steer + touch_steer, -1.0, 1.0), (kb_up or touch_up), (kb_down or touch_down)

    def spawn_obstacle(self):
        kind = "rock" if random.random() < 0.42 else "tree"
        tex = self.textures[kind]
        x = random.uniform(36.0, max(36.0, self.width - 36.0))
        if self.distance > 450 and abs(x - self.player_x) < 74 and random.random() < 0.65:
            x += random.choice([-1.0, 1.0]) * random.uniform(125.0, 195.0)
            x = clamp(x, 36.0, max(36.0, self.width - 36.0))
        y = -random.uniform(55.0, 140.0)
        self.obstacles.append(Obstacle(kind, tex, x, y))

    def update(self, dt):
        dt = min(dt, 1.0 / 20.0)
        if self.game_over or self.paused:
            self._refresh_text()
            self.redraw()
            return

        steer, up, down = self._input_state()
        self.player_vx = clamp(self.player_vx + steer * 920.0 * dt, -430.0, 430.0)
        if abs(steer) < 0.05:
            self.player_vx *= max(0.0, 1.0 - 6.5 * dt)
        self.player_x = clamp(self.player_x + self.player_vx * dt, 28.0, max(28.0, self.width - 28.0))

        if up:
            self.boost += 36.0 * dt
        elif down:
            self.boost -= 54.0 * dt
        else:
            self.boost *= max(0.0, 1.0 - 1.35 * dt)
        self.boost = clamp(self.boost, -14.0, 20.0)
        self.speed_mps = clamp(22.0 + self.boost + min(8.0, self.distance * 0.0012), 8.0, 48.0)

        self.distance += self.speed_mps * dt
        self.score = int(self.distance * 10.0)

        interval = clamp(0.62 - self.distance / 9000.0, 0.16, 0.62)
        self.spawn_timer -= dt
        while self.spawn_timer <= 0.0:
            self.spawn_obstacle()
            self.spawn_timer += interval * random.uniform(0.72, 1.28)

        scroll_px = self.speed_mps * PX_PER_METER
        alive = []
        for ob in self.obstacles:
            ob.y += scroll_px * dt
            if ob.y - ob.h * 0.5 < self.height + 110.0:
                alive.append(ob)
        self.obstacles = alive

        if self.distance >= YETI_START_DISTANCE and not self.yeti_active:
            self.yeti_active = True
            self.yeti_x = clamp(self.player_x + random.choice([-95.0, 95.0]), 42.0, max(42.0, self.width - 42.0))
            self.yeti_y = self.height + 170.0
            self.yeti_speed = max(25.0, self.speed_mps + 1.5)

        if self.yeti_active:
            enraged = max(0.0, self.distance - YETI_START_DISTANCE) * 0.0022
            self.yeti_speed = max(self.yeti_speed, self.speed_mps + 2.0 + enraged)
            closing = (self.yeti_speed - self.speed_mps + 5.0) * PX_PER_METER
            self.yeti_y -= closing * dt
            dx = self.player_x - self.yeti_x
            self.yeti_x += clamp(dx, -1.0, 1.0) * min(abs(dx), 295.0 * dt)

        pw, ph = self.textures["skier"].width * 0.28, self.textures["skier"].height * 0.34
        for ob in self.obstacles:
            ohw, ohh = ob.half_size()
            if overlap(self.player_x, self.player_y, pw, ph, ob.x, ob.y, ohw, ohh):
                self.game_over = True
                self.message_text = "GAME OVER\nYou hit a {}!\nTap or press R to restart".format(ob.kind)
                self.message_color = WHITE
                break

        if self.yeti_active:
            yw, yh = self.textures["yeti"].width * 0.34, self.textures["yeti"].height * 0.38
            if overlap(self.player_x, self.player_y, pw, ph, self.yeti_x, self.yeti_y, yw, yh):
                self.game_over = True
                self.message_text = "GAME OVER\nThe Yeti caught you!\nTap or press R to restart"
                self.message_color = WHITE

        self._refresh_text()
        self.redraw()

    def _refresh_text(self):
        self.hud_text = "Score {:07d}   Distance {:6.1f} m   Speed {:4.1f} m/s".format(
            self.score, self.distance, self.speed_mps
        )
        if self.paused and not self.game_over:
            self.message_text = "PAUSED\nPress P to continue"
            self.message_color = WHITE
        elif not self.game_over:
            if 1700.0 < self.distance < YETI_START_DISTANCE:
                self.message_text = "YETI INCOMING!"
                self.message_color = RED
            elif self.yeti_active:
                gap = max(0.0, self.yeti_y - self.player_y)
                self.message_text = "YETI BEHIND YOU: {:4.0f} px".format(gap)
                self.message_color = RED
            else:
                self.message_text = ""
                self.message_color = WHITE

    def redraw(self):
        w, h = self.width, self.height
        self.canvas.before.clear()
        self.canvas.clear()

        with self.canvas.before:
            Color(*SNOW)
            Rectangle(pos=(0, 0), size=(w, h))
            offset = (self.distance * PX_PER_METER) % 140.0
            Color(*SNOW_LINE)
            y = -140.0 + offset
            while y < h + 160.0:
                Line(points=[0, y, w, y + 30.0], width=1.2)
                y += 140.0
            Color(*SIDE_LINE)
            Line(points=[18, 0, 18, h], width=3)
            Line(points=[w - 18, 0, w - 18, h], width=3)

        with self.canvas:
            for ob in self.obstacles:
                Color(1, 1, 1, 1)
                Rectangle(texture=ob.tex, pos=(ob.x - ob.w / 2.0, ob.y - ob.h / 2.0), size=(ob.w, ob.h))

            if self.yeti_active:
                tex = self.textures["yeti"]
                Rectangle(texture=tex, pos=(self.yeti_x - tex.width / 2.0, self.yeti_y - tex.height / 2.0), size=(tex.width, tex.height))

            tex = self.textures["skier"]
            Color(1, 1, 1, 1)
            Rectangle(texture=tex, pos=(self.player_x - tex.width / 2.0, self.player_y - tex.height / 2.0), size=(tex.width, tex.height))

            if self.game_over or self.paused:
                Color(*SHADE)
                Rectangle(pos=(0, 0), size=(w, h))


class SkiApp(App):
    def build(self):
        self.title = "2D Ski Adventure"
        root = FloatLayout()
        self.board = GameBoard()
        root.add_widget(self.board)

        self.hud = Label(
            text="",
            color=HUD,
            font_size="16sp",
            size_hint=(1, None),
            height=38,
            pos_hint={"x": 0, "top": 1},
            halign="left",
            valign="middle",
            padding=(12, 0),
        )
        self.hud.bind(size=self._sync_text_size)
        root.add_widget(self.hud)

        self.message = Label(
            text="",
            color=WHITE,
            font_size="30sp",
            size_hint=(1, None),
            height=220,
            pos_hint={"x": 0, "center_y": 0.62},
            halign="center",
            valign="middle",
        )
        self.message.bind(size=self._sync_text_size)
        root.add_widget(self.message)

        Clock.schedule_interval(self.refresh_labels, 1.0 / 30.0)
        return root

    def _sync_text_size(self, inst, size):
        inst.text_size = size

    def refresh_labels(self, dt):
        self.hud.text = self.board.hud_text
        if self.message.text != self.board.message_text:
            self.message.text = self.board.message_text
        self.message.color = self.board.message_color


if __name__ == "__main__":
    SkiApp().run()
