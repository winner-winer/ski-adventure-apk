# Ski Adventure Android 构建包

这是 Kivy 版滑雪大冒险，可用 GitHub Actions 自动构建 APK。已加入触屏控制，平板上不需要键盘。

## 用 GitHub Actions 构建 APK（推荐）

1. 新建一个 GitHub 仓库。
2. 把本目录里的**所有内容**上传到仓库根目录，包括：
   - `main.py`
   - `buildozer.spec`
   - `assets/` 四张 PNG
   - `.github/workflows/build-apk.yml`
3. 打开 GitHub 仓库页面 → Actions → **Build Android APK** → Run workflow。
4. 等构建完成后，在该次运行页面的 Artifacts 里下载 `ski-adventure-debug-apk`。
5. 把 APK 传到平板，安装时允许“安装未知来源应用”。

> 首次构建会下载 Android SDK/NDK，通常要 10–30 分钟；之后有缓存会快很多。

## 本地 x86_64 Ubuntu 构建（可选）

```bash
sudo apt-get update
sudo apt-get install -y git zip unzip openjdk-17-jdk autoconf libtool pkg-config zlib1g-dev libncurses5-dev libncursesw5-dev libtinfo5 cmake libffi-dev libssl-dev build-essential ccache
python3 -m pip install --upgrade pip
python3 -m pip install buildozer cython==0.29.36
buildozer -v android debug
# 产物在 bin/*.apk
```

## 操作

- 触屏：手指在滑雪者左边/右边拖动来转向；靠近屏幕顶部加速，靠近底部刹车；游戏结束后点屏幕重开。
- 键盘：`←/→` 转向，`↑` 加速，`↓` 刹车，`P` 暂停，`R` 重开。

替换素材：直接替换 `assets/skier.png`、`assets/tree.png`、`assets/rock.png`、`assets/yeti.png` 后再构建。
