[app]
title = Ski Adventure
package.name = skiadventure
package.domain = org.minis.skiadventure
source.dir = .
source.include_exts = py,png,md,txt
version = 0.1
requirements = python3,kivy
orientation = portrait
fullscreen = 1
icon.filename = assets/skier.png

# Android build settings. Buildozer/python-for-android will download the
# Android SDK/NDK into ~/.buildozer on the CI runner.
android.api = 33
android.minapi = 21
android.ndk = 25b
android.archs = arm64-v8a
android.debug_artifact = apk
android.release_artifact = aab
android.permissions =
android.accept_sdk_license = True

[buildozer]
log_level = 2
warn_on_root = 0
